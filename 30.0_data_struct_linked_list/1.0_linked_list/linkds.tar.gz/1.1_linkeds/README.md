# 编译为 android 或 ios 应用
    安装编译工具
    go get golang.org/x/mobile/cmd/gomobile 
    gomobile init
    例子
    go get -d golang.org/x/mobile/example/basic


